
let panier = [];

function ajouterAuPanier(nom, prix) {
  panier.push({ nom, prix });
  afficherPanier();
}

function afficherPanier() {
  const liste = document.getElementById("liste-panier");
  const total = document.getElementById("total");
  const compteur = document.getElementById("compteur-panier");
  const panierSection = document.getElementById("panier");

  liste.innerHTML = "";
  let somme = 0;

  panier.forEach((item, index) => {
    const li = document.createElement("li");
    li.textContent = `${item.nom} - ${item.prix.toFixed(2)} €`;
    const btn = document.createElement("button");
    btn.textContent = "Supprimer";
    btn.onclick = () => {
      supprimerDuPanier(index);
    };
    li.appendChild(btn);
    liste.appendChild(li);
    somme += item.prix;
  });

  total.textContent = somme.toFixed(2);
  compteur.textContent = panier.length;
  panierSection.classList.remove("hidden");
}

function supprimerDuPanier(index) {
  panier.splice(index, 1);
  afficherPanier();
}

function viderPanier() {
  panier = [];
  afficherPanier();
  document.getElementById("panier").classList.add("hidden");
}

document.getElementById("panier-btn").addEventListener("click", () => {
  document.getElementById("panier").classList.toggle("hidden");
});
